#include <stdio.h>
void main(){
	int sum=0;
     for(int i=102;i<=999;i+=17){
              sum+=i;}
     printf("%d\n",sum);
}

